import UIKit

let LightSpeed = 186_282
let  SunDist = 92_960_000
var SunLightTravel = SunDist / LightSpeed

print("Light from the Sun will reach the Earth in approx. :")
print(SunLightTravel)
print("Seconds")
